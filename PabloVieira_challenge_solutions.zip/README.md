# Challenge performed by Pablo Vieira - 07/11/19

Source code for the two challenges questions sent via email by Davie Bruce

## Getting Started

In order to see the final result and output, please run the index.html file and check the console of the browser.

### Quick Note

Wish I could have more than 2 hours to demonstrate my HTML and CSS skills.
However, I preferred to use the time to focus on the logic and quality of the code delivered.

Thanks,

Pablo Vieira